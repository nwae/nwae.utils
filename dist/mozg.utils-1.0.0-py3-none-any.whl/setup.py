from setuptools import setup

setup(
    name='mozg.utils',
    version='1.0.0',
    packages=[''],
    package_dir={'': 'src'},
    url='',
    license='',
    author='mark.tan',
    author_email='mapktah@yandex.ru',
    description='Basic Utilities'
)
